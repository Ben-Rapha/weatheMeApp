package projectsoftware.gomezsantiago.com.weathermeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.testfairy.TestFairy;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {

    private EditText login;
    private EditText password;
    private TextView loginErr;
    private final String BASE_URL =
            "http://68.195.41.196:8080/Weather_Servlet/User_RMI?method=isvaliduser&username=";
    private boolean loginSuccess = false;
    String username;
    String pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TestFairy.begin(this, "489d5a9dade7d4f14cf3db74a64011aaabc07769");

        login = findViewById(R.id.login_username);
        password = findViewById(R.id.login_password);
        Button loginBtn = findViewById(R.id.login_btn);
        TextView registerLink = findViewById(R.id.register_link);
        loginErr = findViewById(R.id.login_error);

        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                loginErr.setVisibility(View.GONE);
                //validate user input
                try{
                    username = login.getText().toString().trim().toLowerCase();
                    pass = password.getText().toString();
                    /**1)VALIDATE INPUT BY MAKING SURE ONLY LETTERS AND NUMBERS ARE USED
                     * 2)ENCRYPT PASSWORD
                     * 3)MAKE SURE INPUT IS NOT EMPTY (already done)
                     * 4)MAKE SURE NO SQLINJECTION (step 1 may already take care of this)**/
                    if(username != null && pass != null){
                    String[] param = { BASE_URL,username,pass};
                    new GetJSONTask().execute(param);
                    }
                    else{
                        loginErr.setVisibility(View.VISIBLE);
                    }
                } catch(NullPointerException e){
                    loginErr.setVisibility(View.VISIBLE);
                }catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    private class GetJSONTask extends AsyncTask<String, Void, String> {
        private ProgressDialog pd; //for loading wheel

         @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //show loading wheel
            pd = ProgressDialog.show(LoginActivity.this, "", "Loading", true,
                    false); // Create and show Progress dialog
        }

        @Override
        protected String doInBackground(String... params) {
            try {//BASE_URL,username, password
                loginSuccess = UserAccount.createOrValidateUser(params[0], params[1], params[2]);
            } catch (IOException e) {
                return "Unable to retrieve data. URL may be invalid.";
            }
                return "executed";
        }

        // onPostExecute displays the results of the doInBackgroud and also we
        // can hide progress dialog.
        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
                if(loginSuccess) {
                    loginErr.setVisibility(View.GONE);
                    Intent mIntent;
                    mIntent = new Intent(LoginActivity.this, ChangeLocation.class);
                    Bundle extras = mIntent.getExtras();
                    if (extras != null) {
                        extras.putString("Go_To_Fragment", "LocationTab");
                        mIntent.putExtras(extras);
                        startActivity(mIntent);
                    }
                }
                //display error messages
                else {
//                    loginErr.setText(getString(R.string.loginError));
                    loginErr.setVisibility(View.VISIBLE);
                }
        }
    }
}


