package projectsoftware.gomezsantiago.com.weathermeapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class WeatherJsonParser {
    private static final String TEMPERATURE ="temp_F";
    private static final String WEATHER_DESCRIPTION = "weatherDesc";
    private static final String DESCRIPTION_VALUE = "value";
    private static final String CURRENT_CONDITION = "current_condition";
    private static final String ASTRONOMY = "astronomy";
    private static final String WEATHER_ICON_URL = "weatherIconUrl";
    private static final String WEATHER = "weather";

    public static WeatherModel parseWeatherJson(String json) {
        WeatherModel weather = null;
        try {
            JSONObject weatherDataObject = new JSONObject(json);
            JSONArray currentConditionJsonArray = weatherDataObject.getJSONArray(CURRENT_CONDITION);
            JSONObject currentWeatherConditionObject = currentConditionJsonArray.getJSONObject(2);
            String temperature = currentWeatherConditionObject.optString(TEMPERATURE);
            JSONArray  weatherDescriptionJsonArray = currentConditionJsonArray.getJSONArray(5);
            JSONObject temperatureObject = weatherDescriptionJsonArray.getJSONObject(0);
            String weatherDescription = temperatureObject.optString(DESCRIPTION_VALUE);
            JSONArray weatherIconUrlJsonArray = currentConditionJsonArray.getJSONArray(4);
            JSONObject weatherIconObject = weatherIconUrlJsonArray.getJSONObject(0);
            String iconUrl = weatherIconObject.optString(WEATHER_ICON_URL);
            JSONArray weatherDetailObject = weatherDataObject.getJSONArray(WEATHER);
            JSONArray astronomyJsonArray = weatherDetailObject.getJSONArray(1);
            String sunrise = astronomyJsonArray.optString(0);
            String sunset = astronomyJsonArray.optString(1);
            weather = new WeatherModel(sunrise,sunset,weatherDescription,temperature,iconUrl);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return weather;
    }


    /*
    How to call this method
    after receiving the data from the network call, parse the data using this method
    example
    WeatherModel weather = WeatherJsonParser.parseWeatherJson(data string here);
    note WeatherModel is a class that holds weather values.
    you can now call method like weather.getTemperature and it will return the temperature value
     */
}