package projectsoftware.gomezsantiago.com.weathermeapp;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherData {

    public static String getWeatherData(String city, String country, String BASE_URL) throws IOException {
        HttpURLConnection conn = null;
        InputStream in = null;

           try {
            conn = (HttpURLConnection) (new URL(BASE_URL+city
                                        +"&country="+country)).openConnection();
               conn.setRequestMethod("GET");
               conn.setDoInput(true);
               conn.connect();

               //Read response
               StringBuffer strBuff = new StringBuffer();
               in = conn.getInputStream();
               BufferedReader buffRead = new BufferedReader(new InputStreamReader(in));
               String line = null;

               while ((line = buffRead.readLine()) != null) {
                   strBuff.append(line + "\r\n");
               }
               return strBuff.toString();
           } finally{
            in.close();
            conn.disconnect();
           }
    }

    public static String[] parseJSON(JSONObject data){
        String stringify[] = null;


        return stringify;
    }
}
