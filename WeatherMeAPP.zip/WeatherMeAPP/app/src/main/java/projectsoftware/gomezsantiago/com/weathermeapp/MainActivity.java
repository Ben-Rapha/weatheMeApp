package projectsoftware.gomezsantiago.com.weathermeapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import com.testfairy.TestFairy;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;

import projectsoftware.gomezsantiago.com.weathermeapp.R;
import projectsoftware.gomezsantiago.com.weathermeapp.WeatherAPI;

public class MainActivity extends AppCompatActivity implements OnClickListener, OnItemSelectedListener {
    private static final String TAG = "MainActivity";

    private SharedPreferences settings;
    private SharedPreferences.Editor editor;

    private EditText weatherList_textField1;
    private EditText weatherListIndex_textField1;
    private EditText weatherListItem_textField1;

    private Button submit_getWeatherInfo;

    private String[] weatherInfoList;
    private String queryString = "";

    private Spinner spinner;
    private String[] items = {
            "WeatherChannel",
            "Google",
            "OpenWeatherAPI"
    };

    String urlString = "";

    //FOR USE WITH API
    private final String apiKey = "2ab4eb6ee8f751c8e18a9b3b4bd83fca";
    private String URL;
    private String unit = "imperial"; //the units used for the weather information {ft, °F,...}
    private boolean useAPI; //will an API be used?
    private String zipcode;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TestFairy.begin(this, "489d5a9dade7d4f14cf3db74a64011aaabc07769");

        settings = PreferenceManager.getDefaultSharedPreferences(this);
        editor = settings.edit();

        setContentView(R.layout.activity_main);

        submit_getWeatherInfo = (Button) findViewById(R.id.button_getWeatherInfo);
        submit_getWeatherInfo.setBackgroundColor(Color.LTGRAY);
        submit_getWeatherInfo.setOnClickListener(this);

        spinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_spinner_item, items);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        weatherListItem_textField1 = (EditText) findViewById(R.id.editText1_weatherItem);
        weatherListItem_textField1.setBackgroundColor(Color.GRAY);
        weatherListItem_textField1.setTextColor(Color.parseColor("#000000"));
        weatherListItem_textField1.setText(settings.getString("selection_queryString", ""));

        weatherInfoList = new String[10];

        //allow search by keyboard input
        weatherListItem_textField1.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        event.getAction() == KeyEvent.ACTION_DOWN
                                && event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    onClick(submit_getWeatherInfo);
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub
        urlString = (String) parent.getItemAtPosition(0);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
//                urlString = (String) parent.getItemAtPosition(0);
                urlString = "https://weather.com/weather/today/l/";
                break;
            case 1:
//                urlString = (String) parent.getItemAtPosition(1);
                urlString = "http://www.google.com/search?q=Weather+";
                break;
            case 2:
                urlString = "https://api.openweathermap.org/data/2.5/weather?zip=";
                break;
        }
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        String validateResult = weatherListItem_textField1.getText().toString();
        if(!validateResult.matches("[0-9]{5}")){
            Toast.makeText(MainActivity.this,"please only enter 5 digits 0-9 as zipcode", Toast.LENGTH_LONG).show();
            return;
        }

        if (v == submit_getWeatherInfo) {
            this.useAPI = false;
            String query = "";
            String searchString = weatherListItem_textField1.getText().toString();

            if (urlString.equals("http://www.google.com/search?q=Weather+")) {
                searchString = searchString.trim().replaceAll("\\s+", " ").replace(" ", "+");
            }
            if (urlString.equals("https://api.openweathermap.org/data/2.5/weather?zip=")) {
                zipcode = searchString;
                this.URL = urlString + zipcode + ",US&units=" + unit + "&APPID=" + this.apiKey;
                this.useAPI = true;
            }

            query = urlString + searchString;
            Log.e(TAG, query);

            URL url;
            //get the png icon corresponding to the weather: "http://openweathermap.org/img/w/"+icon+".png";

            //get weather data from API
            if (this.useAPI) {
                RequestQueue queue = Volley.newRequestQueue(this);
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try{

                                    JSONObject JsonObj = response.getJSONObject("sys");
                                    weatherInfoList[0] = JsonObj.getString("country");
                                    weatherInfoList[1] = response.getString("name");
                                    weatherInfoList[2] = zipcode;

                                    JsonObj = response.getJSONObject("main");
                                    weatherInfoList[3] = JsonObj.getString("temp");
                                    weatherInfoList[4] = JsonObj.getString("temp_min");
                                    weatherInfoList[5] = JsonObj.getString("temp_max");
                                    weatherInfoList[6] = JsonObj.getString("humidity");

                                    JsonObj = response.getJSONObject("wind");
                                    weatherInfoList[7] = JsonObj.getString("speed");

                                    JSONArray JsArr = response.getJSONArray("weather");
                                    weatherInfoList[8] = JsArr.getJSONObject(0).getString("description");
                                    weatherInfoList[9] = JsArr.getJSONObject(0).getString("icon");

                                    Intent intent = new Intent(MainActivity.this, WeatherAPI.class);
                                    intent.putExtra("weatherInfo", weatherInfoList);
                                    startActivity(intent);

                                }catch(Exception e){
                                    Log.d("JSON Error", e.getMessage());
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", error.getMessage());
                    }
                });
                queue.add(request);
            }

            //display web weather results
            else {
                try {
                    url = new URL(query);

                    WebView myWebView = (WebView) findViewById(R.id.webview);
                    myWebView.getSettings().setJavaScriptEnabled(true);
                    myWebView.clearCache(true);
                    myWebView.loadUrl(url.toString());
                    myWebView.setWebViewClient(new WebViewClient());

                } catch (MalformedURLException e) {
                    // TODO Auto-generated catch block
                    Log.d("URL Error", e.getMessage());
                }
            }
        }

    }
}

