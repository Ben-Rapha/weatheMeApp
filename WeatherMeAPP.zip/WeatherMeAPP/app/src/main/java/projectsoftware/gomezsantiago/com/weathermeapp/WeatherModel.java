package projectsoftware.gomezsantiago.com.weathermeapp;

public class WeatherModel {

    private String sunRise,sunSet,weatherDescription,temperature,imageUrl;

    public WeatherModel( String sunRise,String sunSet,String weatherDescription,String temperature,String imageUrl){
        this.sunRise = sunRise;
        this.sunSet = sunSet;
        this.weatherDescription = weatherDescription;
        this.temperature = temperature;
        this.imageUrl = imageUrl;
    }

    public String getSunRise() {
        return sunRise;
    }

    public String getSunSet() {
        return sunSet;
    }

    public String getWeatherDescription() {
        return weatherDescription;
    }

    public void setSunRise(String sunRise) {
        this.sunRise = sunRise;
    }

    public void setSunSet(String sunSet) {
        this.sunSet = sunSet;
    }

    public void setWeatherDescription(String weatherDescription) {
        this.weatherDescription = weatherDescription;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
