package projectsoftware.gomezsantiago.com.weathermeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.testfairy.TestFairy;

import java.io.IOException;

public class RegisterActivity extends AppCompatActivity {
    private EditText user;
    private EditText password;
    private EditText c_password;
    private TextView regErr;
    private final String BASE_URL =
            "http://68.195.41.196:8080/Weather_Servlet/User_RMI?method=createuser&username=";
    private boolean registerSuccess = false;
    String username;
    String cpass;
    String pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        TestFairy.begin(this, "489d5a9dade7d4f14cf3db74a64011aaabc07769");

        regErr = findViewById(R.id.register_error);
        user = findViewById(R.id.register_username);
        password = findViewById(R.id.login_password);
        c_password = findViewById(R.id.confirm_password);
        Button registerBtn = findViewById(R.id.register_btn);
        TextView loginLink = findViewById(R.id.login_link);
        loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //validate user input
              try{
                  username = user.getText().toString().trim().toLowerCase();
                  pass = password.getText().toString();
                  cpass = c_password.getText().toString();

                  /**1)VALIDATE INPUT BY MAKING SURE ONLY LETTERS AND NUMBERS ARE USED
                   * 2)ENCRYPT PASSWORD
                   * 3)MAKE SURE NO SQLINJECTION (step 1 may already take care of this)**/

                  if(username != null && pass != null && cpass != null){
                      if(pass == cpass) {
                          String[] param = {BASE_URL, username, pass};
                          try {
                              new GetJSONTask().execute(param);
                          } catch (Exception e) {
                              e.printStackTrace();
                          }
                      }
                  }
              }
                catch(NullPointerException e){
                  regErr.setVisibility(View.VISIBLE);
                }
            }
        });
    }
    private class GetJSONTask extends AsyncTask<String, Void, String> {
        private ProgressDialog pd; //for loading wheel

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //show loading wheel
            pd = ProgressDialog.show(RegisterActivity.this, "", "Loading", true,
                    false); // Create and show Progress dialog
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                registerSuccess = UserAccount.createOrValidateUser(params[0], params[1], params[2]);
            } catch (IOException e) {
                return "Unable to retrieve data. URL may be invalid.";
            }
            return "executed";
        }

        // onPostExecute displays the results of the doInBackgroud and also we
        // can hide progress dialog.
        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
            if(registerSuccess) {
                regErr.setVisibility(View.GONE);
                Intent mIntent;
                mIntent = new Intent(RegisterActivity.this, ChangeLocation.class);
                Bundle extras = mIntent.getExtras();
                if (extras != null) {
                    extras.putString("Go_To_Fragment", "LocationTab");
                    mIntent.putExtras(extras);
                    startActivity(mIntent);
                }
            }
        }
    }
}

