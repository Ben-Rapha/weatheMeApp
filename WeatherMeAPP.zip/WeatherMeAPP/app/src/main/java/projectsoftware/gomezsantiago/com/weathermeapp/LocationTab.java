package projectsoftware.gomezsantiago.com.weathermeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;

public class LocationTab extends Fragment {
    private EditText city;
    private EditText country;
    private Button searchBtn;
    private String[] weatherData;

    //FOR USE WITH WorldWeatherOnline API
//    private final String API_KEY = "a16e0132a8d34bf281e182814181012";
//    private final String BASE_URL = "http://api.worldweatheronline.com/premium/v1/weather.ashx?"+
//                                    "format=JSON&num_of_days=5&q=";

    //FOR CONNECTION TO SERVLET
    private final String BASE_URL = "http://68.195.41.196:8080/Weather_Servlet/WeatherServer?city=";
    /*For OpenWeather API
    * private final String BASE_URL = "http://api.openweathermap.org/data/2.5/weather?city=";
    * private final String API_KEY = "2ab4eb6ee8f751c8e18a9b3b4bd83fca";
    * private String unit = "imperial";*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String statusUpdate;
        try{
            statusUpdate = getArguments().getString("status");
        } catch(Exception e){
            statusUpdate = null;
        }
        View rootView = inflater.inflate(R.layout.tab1_get_location, container, false);

        city = (EditText) rootView.findViewById(R.id.enter_city);
        country = (EditText) rootView.findViewById(R.id.enter_country);
        searchBtn = (Button) rootView.findViewById(R.id.search_btn);

        searchBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String[] param = {  city.getText().toString().toLowerCase().trim(),
                                    country.getText().toString().toLowerCase().trim(),
                                    BASE_URL};
                try {
                    new GetJSONTask().execute(param);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        return rootView;
    }

    private class GetJSONTask extends AsyncTask<String, Void, String> {
        private ProgressDialog pd;

        // onPreExecute called before the doInBackgroud start for display
        // progress dialog.
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = ProgressDialog.show(getContext(), "", "Loading", true,
                    false); // Create and show Progress dialog
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                return WeatherData.getWeatherData(params[0], params[1], params[2]);
            } catch (IOException e) {
                return "Unable to retrieve data. URL may be invalid.";
            }
        }

        // onPostExecute displays the results of the doInBackgroud and also we
        // can hide progress dialog.
        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
            try {
                weatherData = WeatherData.parseJSON(new JSONObject(result));
                Intent intent = new Intent(getActivity(), WeatherAPI.class);
                intent.putExtra("weatherInfo", weatherData);
                startActivity(intent);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
