package projectsoftware.gomezsantiago.com.weathermeapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.testfairy.TestFairy;

public class WeatherAPI extends AppCompatActivity {
    private TextView wLocation;
    private TextView wFeelsLike;
    private TextView wTemp;
    private TextView wWindspeed;
    private TextView wDesc;
    private TextView wprecipitation;
    private TextView wVisibility;
    private TextView whumidity;
    private TextView wsunrise;
    private TextView wsunset;
    private ImageView wIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TestFairy.begin(this, "489d5a9dade7d4f14cf3db74a64011aaabc07769");
        setContentView(R.layout.activity_weather_api);

        Bundle extras = this.getIntent().getExtras();
        wIcon = (ImageView) findViewById(R.id.mainWeather_icon);
        wLocation = (TextView) findViewById(R.id.show_location);
        wTemp = (TextView) findViewById(R.id.mainWeather_temp);
        wDesc = (TextView) findViewById(R.id.mainWeather_desc);

        wWindspeed = (TextView) findViewById(R.id.mainWeather_windspeed);
        wprecipitation = (TextView) findViewById(R.id.mainWeather_precip);
        whumidity = (TextView) findViewById(R.id.mainWeather_humidity);
        wFeelsLike = (TextView) findViewById(R.id.mainWeather_feels);
        wVisibility = (TextView) findViewById(R.id.mainWeather_visibility);
        wsunrise = (TextView) findViewById(R.id.mainWeather_sunrise);
        wsunset = (TextView) findViewById(R.id.mainWeather_sunset);

        if(extras != null){
//            String [] wDetails = extras.getStringArray("weatherInfo");
//
//            char degree = '\u00B0';
//            wLocation.setText(wDetails[1]+", "+wDetails[0]);
//            wTemp.setText(wDetails[3]+" "+degree+"F");
//            wWindspeed.setText(wDetails[7]+" mph");
//            wDesc.setText(wDetails[8]);
//            whumidity.setText(wDetails[6]+"%");
        }
    }
}