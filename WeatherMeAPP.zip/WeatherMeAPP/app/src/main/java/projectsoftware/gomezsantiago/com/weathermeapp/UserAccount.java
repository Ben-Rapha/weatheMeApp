package projectsoftware.gomezsantiago.com.weathermeapp;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UserAccount {

    //BASE_URL Determines if creating or validating a user

    public static boolean createOrValidateUser(String BASE_URL, String username, String password) throws IOException {
        HttpURLConnection conn = null;
        boolean success = false;

        try {
            conn = (HttpURLConnection) (new URL(BASE_URL + username
                    + "&password=" + password+"&city=null&country=null")).openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();
            success = true;
        } finally {
            try{
            conn.disconnect();
            } catch(NullPointerException ne){
                success = false;
                ne.printStackTrace();
            }
        }
        return success;
    }

    public static boolean isUser(String BASE_URL, String username) throws IOException {
        HttpURLConnection conn = null;
        boolean isuser = false;

        try {
            conn = (HttpURLConnection) (new URL(BASE_URL + username+
                    "&password=null&city=null&country=null")).openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();
            isuser = true;
        } finally {
            try{
                conn.disconnect();
            } catch(NullPointerException ne){
                isuser = false;
                ne.printStackTrace();
            }
        }
        return isuser;
    }

    //BASE_URL Determines if adding or deleting a favorite location
    public static boolean AddOrDeleteFavorite(String BASE_URL, String username, String city, String country) throws IOException {
        HttpURLConnection conn = null;
        boolean success = false;

        try {
            conn = (HttpURLConnection) (new URL(BASE_URL + username
                    + "&city=" + city+"&country="+country+"&password=null")).openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();
            success = true;
        } finally {
            try{
                conn.disconnect();
            } catch(NullPointerException ne){
                success = false;
                ne.printStackTrace();
            }
        }
        return success;
    }

    public static String getFavorite(String BASE_URL, String username) throws IOException {
        HttpURLConnection conn = null;
        InputStream in = null;

        try {
            conn = (HttpURLConnection) (new URL(BASE_URL + username
                    +"&password=null&city=null&country=null")).openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();

            //Read response
            StringBuffer strBuff = new StringBuffer();
            in = conn.getInputStream();
            BufferedReader buffRead = new BufferedReader(new InputStreamReader(in));
            String line = null;
            while ((line = buffRead.readLine()) != null) {
                strBuff.append(line + "\r\n");
            }
            return strBuff.toString();
        } finally {

            try{
                in.close();
                conn.disconnect();
            } catch(NullPointerException ne){
                ne.printStackTrace();
                return null;
            }
        }
    }
}
